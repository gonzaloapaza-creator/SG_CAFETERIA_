/**
 * 
 */
/**
 * 
 */
module SG_RESTAURANTE {
	requires java.desktop;
	requires java.sql;
}